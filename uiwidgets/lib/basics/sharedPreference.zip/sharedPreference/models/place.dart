class Place {
  String name;
  int hmt;
  bool hyb;

  Place({required this.name, required this.hyb, required this.hmt});
}
