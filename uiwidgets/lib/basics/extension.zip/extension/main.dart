import 'package:flutter/material.dart';
import 'package:uiwidgets/basics/extension/pages/home_page.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: HomePage()));
}
