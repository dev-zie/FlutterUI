import 'package:flutter/material.dart';
import 'package:uiwidgets/sliders/views/slider_ui.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: SliderUi()));
}
