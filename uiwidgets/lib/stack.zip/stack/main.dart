import 'package:flutter/material.dart';
import 'package:uiwidgets/stack/views/stack_ui.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: StackUi()));
}
