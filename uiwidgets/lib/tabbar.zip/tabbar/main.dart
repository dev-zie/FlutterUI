import 'package:flutter/material.dart';
import 'package:uiwidgets/tabbar/views/tabbar_ui.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: TabbarUi()));
}
