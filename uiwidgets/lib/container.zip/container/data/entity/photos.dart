class Photos {
  String url;

  Photos({required this.url});
}
