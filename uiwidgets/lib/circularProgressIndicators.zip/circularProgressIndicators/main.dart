import 'package:flutter/material.dart';
import 'package:uiwidgets/circularProgressIndicators/views/circularProgress.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: Circularprogress()));
}
