import 'package:flutter/material.dart';
import 'package:uiwidgets/pageControl/views/main_page.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: MainPage()));
}
