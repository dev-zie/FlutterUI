import 'package:flutter/material.dart';
import 'package:uiwidgets/segmentedColors/views/segmentedColor.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: SegmentedColor(),));
}