import 'package:flutter/material.dart';
import 'package:uiwidgets/theLinearProgressIndicator/views/the_linear_progress_indicator_ui.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: TheLinearProgressIndicatorUI(),debugShowCheckedModeBanner: false,));
}
