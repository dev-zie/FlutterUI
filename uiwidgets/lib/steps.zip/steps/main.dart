import 'package:flutter/material.dart';
import 'package:uiwidgets/steps/views/step_ui.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: StepUi()));
}
