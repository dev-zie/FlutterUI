import 'package:flutter/material.dart';
import 'package:uiwidgets/buttons/views/button_ui.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: ButtonUi()));
}
