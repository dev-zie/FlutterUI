import 'package:flutter/material.dart';
import 'package:uiwidgets/switches/views/switch_ui.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: SwitchUi()));
}
