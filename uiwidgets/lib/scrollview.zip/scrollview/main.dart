import 'package:flutter/material.dart';
import 'package:uiwidgets/slider/views/scrollview_ui.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: ScrollviewUi()));
}
