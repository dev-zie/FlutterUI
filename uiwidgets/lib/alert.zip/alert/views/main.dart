import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:uiwidgets/alert/views/alertui.dart';

void main(List<String> args) {
  runApp(MaterialApp(debugShowCheckedModeBanner: false, home: Alertui()));
}
