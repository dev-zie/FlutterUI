import 'package:flutter/material.dart';

class Alertui extends StatefulWidget {
  const Alertui({super.key});

  @override
  State<Alertui> createState() => _AlertuiState();
}

class _AlertuiState extends State<Alertui> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}